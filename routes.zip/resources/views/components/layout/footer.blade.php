<footer class="bg-white border-t mt-8">
    <div class="max-w-7xl mx-auto py-8 px-4">
        <div class="grid md:grid-cols-4 gap-8">
            <!-- Company Info -->
            <div>
                <h3 class="text-lg font-semibold mb-4">Office Nutrition</h3>
                <p class="text-gray-600">Система управления здоровым питанием в офисе</p>
            </div>
            
            <!-- Quick Links -->
            <div>
                <h3 class="text-lg font-semibold mb-4">Быстрые ссылки</h3>
                <ul class="space-y-2">
                    <li><a href="{{ route('home') }}" class="text-gray-600 hover:text-blue-600">Главная</a></li>
                    @auth
                        <li><a href="{{ route('dashboard') }}" class="text-gray-600 hover:text-blue-600">Дашборд</a></li>
                        <li><a href="{{ route('profile.edit') }}" class="text-gray-600 hover:text-blue-600">Профиль</a></li>
                    @endauth
                </ul>
            </div>
            
            <!-- Support -->
            <div>
                <h3 class="text-lg font-semibold mb-4">Поддержка</h3>
                <ul class="space-y-2">
                    <li class="text-gray-600">Email: support@office-nutrition.ru</li>
                    <li class="text-gray-600">Телефон: +7 (999) 123-45-67</li>
                </ul>
            </div>
            
            <!-- Social -->
            <div>
                <h3 class="text-lg font-semibold mb-4">Мы в соцсетях</h3>
                <div class="flex space-x-4">
                    <a href="#" class="text-gray-600 hover:text-blue-600"><i class="fab fa-telegram fa-lg"></i></a>
                    <a href="#" class="text-gray-600 hover:text-blue-600"><i class="fab fa-vk fa-lg"></i></a>
                </div>
            </div>
        </div>
        
        <!-- Copyright -->
        <div class="border-t mt-8 pt-8 text-center text-gray-600">
            &copy; {{ date('Y') }} Office Nutrition. Все права защищены.
        </div>
    </div>
</footer>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu toggle
    const mobileMenuButton = document.querySelector('.mobile-menu-button');
    const mobileMenu = document.querySelector('.mobile-menu');
    
    if (mobileMenuButton && mobileMenu) {
        mobileMenuButton.addEventListener('click', function() {
            mobileMenu.classList.toggle('hidden');
        });
    }
});
</script>