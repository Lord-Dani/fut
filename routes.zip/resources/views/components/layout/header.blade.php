<nav class="bg-blue-600 text-white shadow-lg">
    <div class="max-w-7xl mx-auto px-4">
        <div class="flex justify-between items-center h-16">
            <!-- Logo -->
            <div class="flex items-center">
                <a href="{{ route('dashboard') }}" class="text-xl font-bold">
                    <i class="fas fa-utensils mr-2"></i>Office Nutrition
                </a>
            </div>

            <!-- Desktop Menu -->
            <div class="hidden md:flex items-center space-x-4">
                @auth
                    <!-- Ролевая навигация -->
                    @if(auth()->user()->isEmployee())
                        @include('components.navigation.employee')
                    @elseif(auth()->user()->isManager())
                        @include('components.navigation.manager')
                    @elseif(auth()->user()->isAdmin())
                        @include('components.navigation.admin')
                    @endif

                    <!-- Профиль пользователя -->
                    @include('components.navigation.user-dropdown')
                @endauth
            </div>

            <!-- Mobile menu button -->
            <div class="md:hidden">
                <button type="button" class="text-white focus:outline-none mobile-menu-button">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
        </div>
        
        <!-- Mobile Menu -->
        <div class="md:hidden mobile-menu hidden">
            @auth
                <div class="px-2 pt-2 pb-3 space-y-1">
                    @if(auth()->user()->isEmployee())
                        @include('components.navigation.employee-mobile')
                    @elseif(auth()->user()->isManager())
                        @include('components.navigation.manager-mobile')
                    @elseif(auth()->user()->isAdmin())
                        @include('components.navigation.admin-mobile')
                    @endif
                </div>
            @endauth
        </div>
    </div>
</nav>