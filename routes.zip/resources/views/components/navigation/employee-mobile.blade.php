@include('components.navigation.nav-item-mobile', [
    'route' => 'dashboard',
    'icon' => 'home',
    'text' => 'Главная'
])
@include('components.navigation.nav-item-mobile', [
    'route' => 'planning.index',
    'icon' => 'calendar-alt',
    'text' => 'Планирование'
])
@include('components.navigation.nav-item-mobile', [
    'route' => 'orders.index',
    'icon' => 'shopping-bag',
    'text' => 'Мои заказы'
])
@include('components.navigation.nav-item-mobile', [
    'route' => 'dishes.my',
    'icon' => 'utensils',
    'text' => 'Мои блюда'
])