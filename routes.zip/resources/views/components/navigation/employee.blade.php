<div class="flex items-center space-x-4">
    @include('components.navigation.nav-item', [
        'route' => 'dashboard',
        'icon' => 'home',
        'text' => 'Главная'
    ])
    @include('components.navigation.nav-item', [
        'route' => 'planning.index',
        'icon' => 'calendar-alt',
        'text' => 'Планирование'
    ])
    @include('components.navigation.nav-item', [
        'route' => 'orders.index',
        'icon' => 'shopping-bag',
        'text' => 'Мои заказы'
    ])
    @include('components.navigation.nav-item', [
        'route' => 'dishes.my',
        'icon' => 'utensils',
        'text' => 'Мои блюда'
    ])
</div>