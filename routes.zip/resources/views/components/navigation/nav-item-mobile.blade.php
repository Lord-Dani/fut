<a href="{{ route($route) }}" 
   class="block px-3 py-2 rounded hover:bg-blue-700 transition {{ request()->routeIs($route . '*') ? 'bg-blue-700' : '' }}">
    <i class="fas fa-{{ $icon }} mr-2 w-4 text-center"></i>{{ $text }}
</a>