<a href="{{ route($route) }}" 
   class="px-3 py-2 rounded hover:bg-blue-700 transition {{ request()->routeIs($route . '*') ? 'bg-blue-700' : '' }}">
    <i class="fas fa-{{ $icon }} mr-1"></i>{{ $text }}
</a>