<div class="relative group">
    <button class="flex items-center space-x-2 px-3 py-2 rounded hover:bg-blue-700 transition">
        <i class="fas fa-user"></i>
        <span>{{ auth()->user()->name }}</span>
        <i class="fas fa-chevron-down text-xs"></i>
    </button>
    <div class="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 hidden group-hover:block z-50">
        <a href="{{ route('profile.edit') }}" class="block px-4 py-2 text-gray-800 hover:bg-gray-100 transition">
            <i class="fas fa-cog mr-2"></i>Настройки
        </a>
        <form method="POST" action="{{ route('logout') }}">
            @csrf
            <button type="submit" class="block w-full text-left px-4 py-2 text-gray-800 hover:bg-gray-100 transition">
                <i class="fas fa-sign-out-alt mr-2"></i>Выйти
            </button>
        </form>
    </div>
</div>