@extends('layouts.app')

@section('title', 'Дашборд')

@section('content')
<div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
    <div class="bg-white rounded-lg shadow p-6">
        <h1 class="text-2xl font-bold mb-4">Добро пожаловать, {{ auth()->user()->name }}!</h1>
        <p class="text-gray-600">Это ваша панель управления.</p>
        
        <!-- Тестовый контент -->
        <div class="mt-6 grid md:grid-cols-3 gap-4">
            <div class="bg-blue-50 p-4 rounded">
                <h3 class="font-semibold">Мои заказы</h3>
                <p class="text-2xl">5</p>
            </div>
            <div class="bg-green-50 p-4 rounded">
                <h3 class="font-semibold">План питания</h3>
                <p class="text-2xl">3</p>
            </div>
            <div class="bg-purple-50 p-4 rounded">
                <h3 class="font-semibold">Блюда</h3>
                <p class="text-2xl">12</p>
            </div>
        </div>
    </div>
</div>

