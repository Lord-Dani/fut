<div class="flex items-center space-x-4">
    <a href="{{ route('admin.dashboard') }}" class="px-3 py-2 rounded hover:bg-blue-700 {{ request()->routeIs('admin.dashboard') ? 'bg-blue-700' : '' }}">
        <i class="fas fa-tachometer-alt mr-1"></i>Панель админа
    </a>
    <a href="{{ route('admin.companies.index') }}" class="px-3 py-2 rounded hover:bg-blue-700 {{ request()->routeIs('admin.companies.*') ? 'bg-blue-700' : '' }}">
        <i class="fas fa-building mr-1"></i>Компании
    </a>
    <a href="{{ route('admin.dishes.index') }}" class="px-3 py-2 rounded hover:bg-blue-700 {{ request()->routeIs('admin.dishes.*') ? 'bg-blue-700' : '' }}">
        <i class="fas fa-utensils mr-1"></i>Блюда
    </a>
    <a href="{{ route('admin.suggestions.index') }}" class="px-3 py-2 rounded hover:bg-blue-700 {{ request()->routeIs('admin.suggestions.*') ? 'bg-blue-700' : '' }}">
        <i class="fas fa-lightbulb mr-1"></i>Предложения
    </a>
    <a href="{{ route('admin.settings') }}" class="px-3 py-2 rounded hover:bg-blue-700 {{ request()->routeIs('admin.settings') ? 'bg-blue-700' : '' }}">
        <i class="fas fa-cogs mr-1"></i>Настройки
    </a>
</div>