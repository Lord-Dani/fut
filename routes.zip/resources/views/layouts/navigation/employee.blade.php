<div class="flex items-center space-x-4">
    <a href="{{ route('dashboard') }}" class="px-3 py-2 rounded hover:bg-blue-700 {{ request()->routeIs('dashboard') ? 'bg-blue-700' : '' }}">
        <i class="fas fa-home mr-1"></i>Главная
    </a>
    <a href="{{ route('planning.index') }}" class="px-3 py-2 rounded hover:bg-blue-700 {{ request()->routeIs('planning.*') ? 'bg-blue-700' : '' }}">
        <i class="fas fa-calendar-alt mr-1"></i>Планирование
    </a>
    <a href="{{ route('orders.index') }}" class="px-3 py-2 rounded hover:bg-blue-700 {{ request()->routeIs('orders.*') ? 'bg-blue-700' : '' }}">
        <i class="fas fa-shopping-bag mr-1"></i>Мои заказы
    </a>
    <a href="{{ route('dishes.my') }}" class="px-3 py-2 rounded hover:bg-blue-700 {{ request()->routeIs('dishes.my') ? 'bg-blue-700' : '' }}">
        <i class="fas fa-utensils mr-1"></i>Мои блюда
    </a>
    <a href="{{ route('dishes.index') }}" class="px-3 py-2 rounded hover:bg-blue-700 {{ request()->routeIs('dishes.index') ? 'bg-blue-700' : '' }}">
        <i class="fas fa-search mr-1"></i>Все блюда
    </a>
</div>