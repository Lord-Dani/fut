<div class="flex items-center space-x-4">
    <a href="{{ route('manager.dashboard') }}" class="px-3 py-2 rounded hover:bg-blue-700 {{ request()->routeIs('manager.dashboard') ? 'bg-blue-700' : '' }}">
        <i class="fas fa-tachometer-alt mr-1"></i>Панель управления
    </a>
    <a href="{{ route('manager.employees.index') }}" class="px-3 py-2 rounded hover:bg-blue-700 {{ request()->routeIs('manager.employees.*') ? 'bg-blue-700' : '' }}">
        <i class="fas fa-users mr-1"></i>Сотрудники
    </a>
    <a href="{{ route('manager.orders.index') }}" class="px-3 py-2 rounded hover:bg-blue-700 {{ request()->routeIs('manager.orders.*') ? 'bg-blue-700' : '' }}">
        <i class="fas fa-clipboard-list mr-1"></i>Заказы
    </a>
    <a href="{{ route('manager.dishes.index') }}" class="px-3 py-2 rounded hover:bg-blue-700 {{ request()->routeIs('manager.dishes.*') ? 'bg-blue-700' : '' }}">
        <i class="fas fa-utensils mr-1"></i>Меню
    </a>
    <a href="{{ route('manager.reports') }}" class="px-3 py-2 rounded hover:bg-blue-700 {{ request()->routeIs('manager.reports') ? 'bg-blue-700' : '' }}">
        <i class="fas fa-chart-bar mr-1"></i>Отчеты
    </a>
</div>