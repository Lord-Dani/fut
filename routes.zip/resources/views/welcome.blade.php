@extends('layouts.app')

@section('title', 'Office Nutrition - Здоровое питание в офисе')

@section('page-content')
<div class="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 py-12">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <!-- Hero Section -->
        <div class="text-center py-16">
            <h1 class="text-5xl font-bold text-gray-900 mb-4">
                <i class="fas fa-utensils text-blue-600"></i>
                Office Nutrition
            </h1>
            <p class="text-xl text-gray-600 mb-8">Система управления здоровым питанием в вашем офисе</p>
            
            @auth
                <a href="{{ route('dashboard') }}" class="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 transition">
                    Перейти в личный кабинет
                </a>
            @else
                <div class="space-x-4">
                    <a href="{{ route('login') }}" class="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 transition">
                        Войти
                    </a>
                    <a href="{{ route('register') }}" class="bg-green-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-green-700 transition">
                        Зарегистрироваться
                    </a>
                </div>
            @endauth
        </div>

        <!-- Features Section -->
        <div class="grid md:grid-cols-3 gap-8 py-12">
            <div class="text-center p-6">
                <i class="fas fa-calendar-alt text-4xl text-blue-600 mb-4"></i>
                <h3 class="text-xl font-semibold mb-2">Планирование питания</h3>
                <p class="text-gray-600">Создавайте индивидуальные планы питания на неделю вперед</p>
            </div>
            
            <div class="text-center p-6">
                <i class="fas fa-heartbeat text-4xl text-green-600 mb-4"></i>
                <h3 class="text-xl font-semibold mb-2">Учет калорий</h3>
                <p class="text-gray-600">Контролируйте пищевую ценность и калорийность блюд</p>
            </div>
            
            <div class="text-center p-6">
                <i class="fas fa-chart-line text-4xl text-purple-600 mb-4"></i>
                <h3 class="text-xl font-semibold mb-2">Аналитика</h3>
                <p class="text-gray-600">Получайте отчеты по питанию и расходам</p>
            </div>
        </div>
    </div>
</div>
@endsection